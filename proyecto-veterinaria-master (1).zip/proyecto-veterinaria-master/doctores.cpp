#include "doctores.h"

//Constructor y Destructor
doctores::doctores(string nom, string Id) : nombre(nom), id(Id) {}
doctores::~doctores() {}

//M�todos Get
string doctores::getId() { return id; }
string doctores::getNombre() { return nombre; }

//M�todo toString
string doctores::toString() {
	stringstream s;
	s << "Nombre" << nombre << endl;
	s << "Id " << id << endl;
	return s.str();
}

