#ifndef DOCTORES_H
#define DOCTORES_H
#include <sstream>
#include <string>
#include <iostream>
#include "especialidad.h"
using namespace std;

class doctores {
private:
	string id;
	string nombre;
public:
	doctores(string, string);
	~doctores();
	string getNombre();
	string getId();
	string toString();
};

#endif


