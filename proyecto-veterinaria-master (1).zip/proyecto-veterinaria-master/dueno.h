#ifndef DUE�O_H
#define DUE�O_H
#include <iostream>
#include <string>
#include <sstream>
#include "mascotas.h"
#define maximo 20
using namespace std;

class dueno {
private:
	string nombre;
	string id;
	int tam;
	int can;
	mascotas** m;
public:
	dueno(string, string);
	~dueno();
	string getNombre();
	string getId();
	void agregarMascotas(mascotas* m1);
	void eliminarMascotas(string);
	string toString();
	string toStringEspecifico();
};

#endif