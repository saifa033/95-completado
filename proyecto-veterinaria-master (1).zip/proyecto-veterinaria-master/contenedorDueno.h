#ifndef CONTENEDOREDUE�O_H
#define CONTENEDOREDUE�O_H
#include "dueno.h"
#define max 10 

class contenedorDueno {
private:
	int tam;
	int can;
	dueno** d;
public:
	contenedorDueno();
	~contenedorDueno();
	void agregarDueno(dueno*);
	void eliminarDueno(string);
	string toString();
};

#endif
