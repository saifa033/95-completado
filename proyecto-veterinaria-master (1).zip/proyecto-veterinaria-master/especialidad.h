#ifndef ESPECIALIDAD_H
#define ESPECIALIDAD_H
#include <sstream>
#include <string>
#include <iostream>
#include "doctores.h"
#define maximoDoc 100
using namespace std;

class especialidad {
private:
	string nombre;
	string id;
	doctores** contDoc;
	int tam;
	int can;
public:
	especialidad(string, string);
	~especialidad();
	void agregarDoctor(doctores* d);
	void eliminarDoctor(string id);
	string getNombre();
	string getId();
	string toString();
	string toStringEspecifico();
	bool buscarPorId(string id);
};
#endif

