#include "especialidad.h"

//Constructor y Destructor
especialidad::especialidad(string nom, string Id) : nombre(nom), id(Id), tam(maximoDoc) {
	can = 0;
	contDoc = new doctores * [tam];
	for (int i = 0; i < tam; i++) {
		contDoc[i] = nullptr;
	}
}
especialidad::~especialidad() {
	for (int i = 0; i < can; i++) {
		if (contDoc[i] != nullptr) {
			delete contDoc[i];
		}
	}
	delete[] contDoc;
}

void especialidad::agregarDoctor(doctores* d) {
	bool existe = false;
	for (int i = 0; i < tam; i++) {
		if (contDoc[i] != nullptr && contDoc[i]->getId() == d->getId()) {
			existe = true;
		}
	}
	if (!existe && can < tam) {
		contDoc[can++] = d;
	}
}

void especialidad::eliminarDoctor(string id) {
	bool verifica = false;
	int indice = -3;
	for (int i = 0; i < can; i++) {
		if (contDoc[i] != nullptr && contDoc[i]->getId() == id) {
			indice = i;
			verifica = true;
		}
	}
	if (verifica == true) {
		delete contDoc[indice];
		for (int i = indice; i < can; i++) {
			contDoc[i] = contDoc[i + 1];
		}
		contDoc[can - 1] = nullptr;
		can--;

	}
}

//M�todos Get
string especialidad::getNombre() { return nombre; }
string especialidad::getId() { return id; }

//M�todos toString
string especialidad::toString() {
	stringstream s;
	s << "Nombre de especialidad:\t" << nombre << endl;
	s << "Identificador de la especialidad:\t" << id << endl;
	return s.str();
}

string especialidad::toStringEspecifico() {
	stringstream ss;
	for (int i = 0; i < can; i++) {
		ss << "Doctores de la especialidad:\n" << contDoc[i]->toString() << endl;
	}
	return ss.str();
}

bool especialidad::buscarPorId(string id) {
	for (int i = 0; i < can; i++) {
		if (contDoc[i] != nullptr && contDoc[i]->getId() == id) {
			return true;
		}
	}
	return false;
}
