#ifndef CONTENEDORESPECIALIDADES_H
#define CONTENEDORESPECIALIDADES_H
#include "Especialidad.h"
#define tama�o 50
class contenededorEspecialidades {
private:
	int tam;
	int can;
	especialidad** e;
public:
	contenededorEspecialidades();
	~contenededorEspecialidades();
	string toString();
	void agregarEspecialidad(especialidad*);
	void eliminarEspecialidad(string);
};

#endif