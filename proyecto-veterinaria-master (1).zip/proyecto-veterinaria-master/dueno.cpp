#include "dueno.h"

//Cosntructor y Destructor
dueno::dueno(string nom, string ced) : nombre(nom), id(ced) {
	tam = maximo;
	can = 0;
	m = new mascotas * [tam];
	for (int i = 0; i < tam; i++) {
		m[i] = nullptr;
	}
}
dueno::~dueno() {
	for (int i = 0; i < can; i++) {
		delete m[i];
	}
	delete[] m;
}

//M�todos Get
string dueno::getNombre() { return nombre; }
string dueno::getId() { return id; }

void dueno::agregarMascotas(mascotas* m1) {
	bool existe = false;
	for (int i = 0; i < tam; i++) {
		if (m[i] != nullptr && m[i]->getNombre() == m1->getNombre()) {
			existe = true;
		}
	}
	if (!existe && can < tam) {
		m[can++] = m1;
	}
}

void dueno::eliminarMascotas(string) {
	bool verifica = false;
	int indice = -3;
	for (int i = 0; i < can; i++) {
		if (m[i] != nullptr && m[i]->getId() == id) {
			indice = i;
			verifica = true;
		}
	}
	if (verifica == true) {
		delete m[indice];
		for (int i = indice; i < can; i++) {
			m[i] = m[i + 1];
		}
		m[can - 1] = nullptr;
		can--;
	}
}

//M�todo toString
string dueno::toString() {
	stringstream s;
	s << "Nombre del propietario:\t" << nombre << endl;
	s << "Id:\t" << id << endl;
	return s.str();
}

string dueno::toStringEspecifico() {
	stringstream t;
	for (int i = 0; i < can; i++) {
		t << "Mascotas del due�o:\n" << m[i]->toString() << endl;
	}
	return t.str();
}
