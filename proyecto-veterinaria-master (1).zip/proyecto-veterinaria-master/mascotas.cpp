#include "mascotas.h"

//Constructores y Destructor
mascotas::mascotas(string nom, string Id, string raz, string tip) : nombre(nom), id(Id), raza(raz), tipo(tip) {}
mascotas::mascotas() : nombre("indef"), id("indef"), raza("indef"), tipo("indef") {}
mascotas::~mascotas() {}

//M�todos Get
string mascotas::getNombre() { return nombre; }
string mascotas::getId() { return id; }
string mascotas::getRaza() { return raza; }
string mascotas::getTipo() { return tipo; }

//M�todo toString
string mascotas::toString() {
	stringstream s;
	s << "Nombre de la mascota:\t" << nombre << endl;
	s << "Identificador:\t" << id << endl;
	s << "Raza:\t" << raza << endl;
	s << "Tipo de mascota:\t" << tipo << endl;
	return s.str();
}