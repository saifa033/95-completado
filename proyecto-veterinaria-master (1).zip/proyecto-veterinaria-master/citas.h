#pragma once
#include <iostream>
#include <string>
#include "doctores.h"
#include "mascotas.h"
#include "dueno.h"
using namespace std;

class citas {
private:
    string fecha;
    string hora;
    doctores* doctor; 
    mascotas* mascota; 
    especialidad* esp;
    dueno* due;

public:
    citas(string fecha, string hora, doctores* d, mascotas* m, dueno* duen, especialidad* e);
    ~citas();

    string getFecha();
    string getHora();
    doctores* getDoctor();
    mascotas* getMascota();
    dueno* getDueno();
    especialidad* getEspecialidad();

    void setFecha(string);
    void setHora(string);
    void setDoctor(doctores*);
    void setMascota(mascotas*);
    void setDueno(dueno*);
    void setEspecialidad(especialidad*);

    string mostrarDetalles();
    void cancelar();
    bool esValida();
};

