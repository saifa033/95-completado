#include "contenedorDueno.h"

//Constructor y Destructor
contenedorDueno::contenedorDueno() {
	tam = max;
	can = 0;
	d = new dueno * [tam];
	for (int i = 0; i < tam; i++) {
		d[i] = NULL;
	}
}
contenedorDueno::~contenedorDueno() {
	for (int i = 0; i < can; i++) {
		delete d[i];
	}
	delete[] d;
}

//M�todo Agregar Due�o
void contenedorDueno::agregarDueno(dueno* dueno1) {
	bool existe = false;
	for (int i = 0; i < tam; i++) {
		if (d[i] != nullptr && d[i]->getNombre() == dueno1->getNombre()) {
			existe = true;
		}
	}
	if (!existe and can < tam) {
		d[can] = dueno1;
		can++;
	}
}

//M�todo Eliminar Due�o
void contenedorDueno::eliminarDueno(string id){
	bool verifica = false;
	int indice = -3;
	for (int i = 0; i < can; i++) {
		if (d[i] != nullptr && d[i]->getId() == id) {
			indice = i;
			verifica = true;
		}
	}
	if (verifica == true) {
		delete d[indice];
		for (int i = indice; i < can; i++) {
			d[i] = d[i + 1];
		}
		d[can - 1] = nullptr;
		can--;
	}
}

//M�todo toString
string contenedorDueno::toString() {
	stringstream s;
	for (int i = 0; i < can; i++) {
		s << d[i]->toString();
	}
	return s.str();
}
