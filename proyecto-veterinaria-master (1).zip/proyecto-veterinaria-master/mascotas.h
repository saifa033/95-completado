#ifndef MASCOTAS_H
#define MASCOTAS_H
#include <iostream>
#include <string>
#include <sstream>
#include "dueno.h"
using namespace std;

class mascotas {
private:
	string nombre;
	string id;
	string raza;
	string tipo;
public:
	mascotas(string, string, string, string);
	mascotas();
	~mascotas();
	string getNombre();
	string getId();
	string getRaza();
	string getTipo();
	string toString();
};
#endif
