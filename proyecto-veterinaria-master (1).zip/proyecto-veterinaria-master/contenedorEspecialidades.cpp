#include "contenedorEspecialidades.h"

//Constructor y Destructor
contenededorEspecialidades::contenededorEspecialidades() {
	tam = tama�o;
	can = 0;
	e = new especialidad * [tam];
	for (int i = 0; i < tam; i++) {
		e[i] = nullptr;
	}
}
contenededorEspecialidades::~contenededorEspecialidades() {
	for (int i = 0; i < can; i++){
		delete e[i];
	}
	delete[] e;
}

//M�todo toString
string contenededorEspecialidades::toString(){
	stringstream s;
	for (int i = 0; i < can ; i++){
		s << e[i]->toString();
	}
	return s.str();
}

//M�todo Agregar Especialidad
void contenededorEspecialidades::agregarEspecialidad(especialidad* e1){
	bool existe = false;
	for (int i = 0; i < tam; i++){
		if (e[i] != nullptr && e[i]->getNombre() == e1->getNombre()) {
			existe = true;
		}
	}
	if (!existe && can < tam) {
		e[can] = e1;
		can++;
	}
}

//M�todo Eliminar Especialidad
void contenededorEspecialidades::eliminarEspecialidad(string id) {
	bool verifica = false;
	int indice = -3;
	for (int i = 0; i < can; i++)	{
		if (e[i] != nullptr && e[i]->getId() == id) {
			indice = i;
			verifica = true;
		}
	}
	if (verifica == true) {
		delete e[indice];
		for (int i = indice; i < can; i++) {
			e[i] = e[i + 1];
		}
		e[can - 1] = nullptr;
		can--;
		
	}
}


