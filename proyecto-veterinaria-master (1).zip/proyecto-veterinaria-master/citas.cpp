#include "citas.h"

// Constructor
citas::citas(string fecha, string hora, doctores* d, mascotas* m, dueno* duen, especialidad* e)
    : fecha(fecha), hora(hora), doctor(d), mascota(m), due(duen), esp(e) {}

citas::~citas() { delete doctor; delete mascota; delete due; delete esp; }

// Getters
string citas::getFecha() { return fecha; }
string citas::getHora() { return hora; }
doctores* citas::getDoctor() { return doctor; }
mascotas* citas::getMascota() { return mascota; } 
dueno* citas::getDueno() { return due; } 
especialidad* citas::getEspecialidad() { return esp; }

// Setters
void citas::setFecha(string f) { fecha = f; }
void citas::setHora(string h) { hora = h; }
void citas::setDoctor(doctores* d) { doctor = d; }
void citas::setMascota(mascotas* m) { mascota = m; }
void citas::setDueno(dueno* d) { due = d; }
void citas::setEspecialidad(especialidad* e) { esp = e; }

// M�todo para mostrar los detalles de la cita
string citas::mostrarDetalles() {
    stringstream r;
    r << "Fecha: " << fecha << endl;
    r << "Hora: " << hora << endl;
    /*r << "Doctor: " << doctor->getNombre() << " (Especialidad: " << doctor->getEspecialidad() << ")" << endl;
    r << "Mascota: " << mascota->getNombre() << " (Due�o: " << mascota->getDuenio()->getNombre() << ")" << endl;*/
}

// M�todo para cancelar la cita
void citas::cancelar() {
    fecha = "";  
    hora = "";   
    doctor = nullptr;
    mascota = nullptr;
    cout << "La cita ha sido cancelada." << endl;
}

// M�todo para verificar si la cita es v�lida
bool citas::esValida() {
    return (fecha != "" && hora != "" && doctor != nullptr && mascota != nullptr);
}
